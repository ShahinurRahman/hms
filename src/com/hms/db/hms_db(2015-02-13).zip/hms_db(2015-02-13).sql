/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.5.8 : Database - db_is_cool
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_is_cool` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_is_cool`;

/*Table structure for table `abc_authority` */

DROP TABLE IF EXISTS `abc_authority`;

CREATE TABLE `abc_authority` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `abc_authority` */

insert  into `abc_authority` values (1,'Super Admin Authority','super_admin');

/*Table structure for table `abc_component` */

DROP TABLE IF EXISTS `abc_component`;

CREATE TABLE `abc_component` (
  `componentId` bigint(20) NOT NULL AUTO_INCREMENT,
  `componentName` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`componentId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `abc_component` */

insert  into `abc_component` values (1,'security','Security Related Module'),(2,'admin','Admin Related Module');

/*Table structure for table `abc_feature` */

DROP TABLE IF EXISTS `abc_feature`;

CREATE TABLE `abc_feature` (
  `featureId` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `operation` varchar(255) DEFAULT NULL,
  `component_componentId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`featureId`),
  KEY `FK13E747D9B39BB5EE` (`component_componentId`),
  CONSTRAINT `FK13E747D9B39BB5EE` FOREIGN KEY (`component_componentId`) REFERENCES `abc_component` (`componentId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `abc_feature` */

insert  into `abc_feature` values (1,'Saving User Feature','saveUser',1),(2,'Creating User Feature','createUser',1),(3,'Creating User Feature','featureList',1),(4,'Listing all User Feature','userList',1),(5,'User List Json Data','userJsonData',1);

/*Table structure for table `abc_group` */

DROP TABLE IF EXISTS `abc_group`;

CREATE TABLE `abc_group` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `abc_group` */

insert  into `abc_group` values (1,'Engineering the whole system having this privilege','System Engineer Group');

/*Table structure for table `abc_group_abc_authority` */

DROP TABLE IF EXISTS `abc_group_abc_authority`;

CREATE TABLE `abc_group_abc_authority` (
  `groupsList_id` bigint(20) NOT NULL,
  `authorityList_id` bigint(20) NOT NULL,
  KEY `FK9F16B609AD9B6161` (`groupsList_id`),
  KEY `FK9F16B60955234557` (`authorityList_id`),
  CONSTRAINT `FK9F16B60955234557` FOREIGN KEY (`authorityList_id`) REFERENCES `abc_authority` (`id`),
  CONSTRAINT `FK9F16B609AD9B6161` FOREIGN KEY (`groupsList_id`) REFERENCES `abc_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `abc_group_abc_authority` */

insert  into `abc_group_abc_authority` values (1,1);

/*Table structure for table `abc_jt_authority_feature` */

DROP TABLE IF EXISTS `abc_jt_authority_feature`;

CREATE TABLE `abc_jt_authority_feature` (
  `AUTHORITY` bigint(20) NOT NULL,
  `FEATURE` bigint(20) NOT NULL,
  KEY `FK7C22A1E2BC89E0E1` (`AUTHORITY`),
  KEY `FK7C22A1E23B5DA307` (`FEATURE`),
  CONSTRAINT `FK7C22A1E23B5DA307` FOREIGN KEY (`FEATURE`) REFERENCES `abc_feature` (`featureId`),
  CONSTRAINT `FK7C22A1E2BC89E0E1` FOREIGN KEY (`AUTHORITY`) REFERENCES `abc_authority` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `abc_jt_authority_feature` */

insert  into `abc_jt_authority_feature` values (1,1),(1,2),(1,3),(1,4),(1,5);

/*Table structure for table `abc_token` */

DROP TABLE IF EXISTS `abc_token`;

CREATE TABLE `abc_token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `abc_token` */

insert  into `abc_token` values (1,'eDqReOp3KcE=','admin');

/*Table structure for table `abc_user` */

DROP TABLE IF EXISTS `abc_user`;

CREATE TABLE `abc_user` (
  `user_type` varchar(31) NOT NULL,
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `active` bit(1) NOT NULL,
  `token_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7B3EF9A899D33AF5` (`token_id`),
  CONSTRAINT `FK7B3EF9A899D33AF5` FOREIGN KEY (`token_id`) REFERENCES `abc_token` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `abc_user` */

insert  into `abc_user` values ('admin',1,'',1);

/*Table structure for table `abc_user_abc_group` */

DROP TABLE IF EXISTS `abc_user_abc_group`;

CREATE TABLE `abc_user_abc_group` (
  `userList_id` bigint(20) NOT NULL,
  `groupList_id` bigint(20) NOT NULL,
  KEY `FKC0CCA64B14E9BE56` (`groupList_id`),
  KEY `FKC0CCA64B736DAAC1` (`userList_id`),
  CONSTRAINT `FKC0CCA64B736DAAC1` FOREIGN KEY (`userList_id`) REFERENCES `abc_user` (`id`),
  CONSTRAINT `FKC0CCA64B14E9BE56` FOREIGN KEY (`groupList_id`) REFERENCES `abc_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `abc_user_abc_group` */

insert  into `abc_user_abc_group` values (1,1);

/*Table structure for table `ad_city` */

DROP TABLE IF EXISTS `ad_city`;

CREATE TABLE `ad_city` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `zip` int(11) DEFAULT NULL,
  `country_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE7D8E007D4797148` (`country_id`),
  CONSTRAINT `FKE7D8E007D4797148` FOREIGN KEY (`country_id`) REFERENCES `ad_country` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `ad_city` */

insert  into `ad_city` values (1,'Dhaka',NULL,1),(2,'Jessore',NULL,1),(3,'Mumby',NULL,2),(4,'Kolkata',NULL,2);

/*Table structure for table `ad_city_country` */

DROP TABLE IF EXISTS `ad_city_country`;

CREATE TABLE `ad_city_country` (
  `CITY_ID` bigint(20) NOT NULL,
  `COUNTRY_ID` bigint(20) NOT NULL,
  UNIQUE KEY `COUNTRY_ID` (`COUNTRY_ID`),
  KEY `FK6F4A733E2ABB4741` (`COUNTRY_ID`),
  KEY `FK6F4A733E3FEF6353` (`CITY_ID`),
  CONSTRAINT `FK6F4A733E3FEF6353` FOREIGN KEY (`CITY_ID`) REFERENCES `ad_country` (`id`),
  CONSTRAINT `FK6F4A733E2ABB4741` FOREIGN KEY (`COUNTRY_ID`) REFERENCES `ad_city` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ad_city_country` */

insert  into `ad_city_country` values (1,1),(1,2),(2,3),(2,4);

/*Table structure for table `ad_city_school` */

DROP TABLE IF EXISTS `ad_city_school`;

CREATE TABLE `ad_city_school` (
  `CITY_ID` bigint(20) NOT NULL,
  `SCHOOL_ID` bigint(20) NOT NULL,
  UNIQUE KEY `SCHOOL_ID` (`SCHOOL_ID`),
  KEY `FK2677A6AC33C2FC2C` (`SCHOOL_ID`),
  KEY `FK2677A6AC9631394C` (`CITY_ID`),
  CONSTRAINT `FK2677A6AC9631394C` FOREIGN KEY (`CITY_ID`) REFERENCES `ad_city` (`id`),
  CONSTRAINT `FK2677A6AC33C2FC2C` FOREIGN KEY (`SCHOOL_ID`) REFERENCES `ad_school` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ad_city_school` */

insert  into `ad_city_school` values (1,2),(2,1);

/*Table structure for table `ad_country` */

DROP TABLE IF EXISTS `ad_country`;

CREATE TABLE `ad_country` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `region_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5945BF5A2E854C2C` (`region_id`),
  CONSTRAINT `FK5945BF5A2E854C2C` FOREIGN KEY (`region_id`) REFERENCES `ad_region` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `ad_country` */

insert  into `ad_country` values (1,'Bangladesh',1),(2,'India',1),(3,'Pakistan',1),(4,'Ghana',2),(5,'New Zealand',3);

/*Table structure for table `ad_department` */

DROP TABLE IF EXISTS `ad_department`;

CREATE TABLE `ad_department` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `school_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2ACB18EE33C2FC2C` (`school_id`),
  CONSTRAINT `FK2ACB18EE33C2FC2C` FOREIGN KEY (`school_id`) REFERENCES `ad_school` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `ad_department` */

insert  into `ad_department` values (1,'Department of Science','Science',1),(2,'Department of Arts','Arts',1),(3,'Department of Business','Business',1);

/*Table structure for table `ad_region` */

DROP TABLE IF EXISTS `ad_region`;

CREATE TABLE `ad_region` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `location` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `ad_region` */

insert  into `ad_region` values (1,NULL,'Asia'),(2,NULL,'Africa'),(3,NULL,'Australia');

/*Table structure for table `ad_region_country` */

DROP TABLE IF EXISTS `ad_region_country`;

CREATE TABLE `ad_region_country` (
  `REGION_ID` bigint(20) NOT NULL,
  `COUNTRY_ID` bigint(20) NOT NULL,
  UNIQUE KEY `COUNTRY_ID` (`COUNTRY_ID`),
  KEY `FK781A2CC7D4797148` (`COUNTRY_ID`),
  KEY `FK781A2CC72E854C2C` (`REGION_ID`),
  CONSTRAINT `FK781A2CC72E854C2C` FOREIGN KEY (`REGION_ID`) REFERENCES `ad_region` (`id`),
  CONSTRAINT `FK781A2CC7D4797148` FOREIGN KEY (`COUNTRY_ID`) REFERENCES `ad_country` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ad_region_country` */

insert  into `ad_region_country` values (1,1),(1,2),(1,3),(2,4),(3,5);

/*Table structure for table `ad_school` */

DROP TABLE IF EXISTS `ad_school`;

CREATE TABLE `ad_school` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `city_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK701467109631394C` (`city_id`),
  CONSTRAINT `FK701467109631394C` FOREIGN KEY (`city_id`) REFERENCES `ad_city` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `ad_school` */

insert  into `ad_school` values (1,'Jessore rail road','Jessore','SSC Label School','Jessore Laboratory School & College',2),(2,'Motijheel Dhaka','Dhaka','College','Notredom College',1);

/*Table structure for table `ad_school_department` */

DROP TABLE IF EXISTS `ad_school_department`;

CREATE TABLE `ad_school_department` (
  `SCHOOL_ID` bigint(20) NOT NULL,
  `DEPARTMENT_ID` bigint(20) NOT NULL,
  UNIQUE KEY `DEPARTMENT_ID` (`DEPARTMENT_ID`),
  KEY `FK6613E1D7F5BE6C` (`DEPARTMENT_ID`),
  KEY `FK6613E133C2FC2C` (`SCHOOL_ID`),
  CONSTRAINT `FK6613E133C2FC2C` FOREIGN KEY (`SCHOOL_ID`) REFERENCES `ad_school` (`id`),
  CONSTRAINT `FK6613E1D7F5BE6C` FOREIGN KEY (`DEPARTMENT_ID`) REFERENCES `ad_department` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ad_school_department` */

insert  into `ad_school_department` values (1,1),(1,2),(1,3);

/*Table structure for table `ad_teacher` */

DROP TABLE IF EXISTS `ad_teacher`;

CREATE TABLE `ad_teacher` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `ad_teacher` */

insert  into `ad_teacher` values (1,'Dhaka','01717659287','Science','Java Engineer','makhomine.java@gmail.com','MA Khomine'),(2,'Lecturer','01939109729','CSE','Head of the Department CSE','alfazhossen@yahoo.com','Alfaz Hossen'),(3,'Dhaka','01944005445','CSE','Teacher','shahin.java24@gmail.com','Shahinur Rahman');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
